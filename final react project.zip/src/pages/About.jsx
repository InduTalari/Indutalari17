import React from 'react'

const About = () => {
  return (
    <div>
      This is our about us page
    </div>
  )
}

export default About
