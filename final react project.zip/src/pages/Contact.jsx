import React from 'react'

const Contact = () => {
  return (
    <div>
      <h1 className="text-2xl m-4">Welcome this is our Contact</h1>
    </div>
  )
}

export default Contact
