import React from 'react'

const Props = () => {
    const name = "John Doe";
    const age = 30;
    const isStudent = false;
    const hobbies = "Reading, Traveling, Coding";

  return (
    <div>
      
    </div>
  )
}

export default Props
