import React from 'react'

const ExmplFunctional = () => {
  return (
    <>
      example functional component
    </>
  )
}

export default ExmplFunctional
// example class component
//now we dont use class component in react
// import React, { Component } from 'react'

// class ExmplClass extends Component { 
//   render() {
//     return (
//       <div>
//         <h1>Example Class Component</h1>
//       </div>
//     )
//   }
// }
// export default ExmplClass
